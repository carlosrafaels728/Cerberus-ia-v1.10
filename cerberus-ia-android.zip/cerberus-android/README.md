# Cerberus IA (Android nativo) — v1.1.0

Asistente de IA creado por **CarlosArt**. Kotlin + Jetpack Compose, minSdk 26 (Android 8+).

## Compilar el APK sin instalar nada (GitHub Actions)
1. Crea un repositorio en GitHub y sube **todo** este proyecto (incluida la carpeta `.github`).
2. Ve a **Actions → Compilar APK → Run workflow** (también corre solo al hacer push).
3. Al terminar (unos 5 min), abre la ejecución y descarga el artefacto **Cerberus-IA-apk** → `app-debug.apk`.
4. Pásalo al teléfono e instálalo (permite "instalar apps de orígenes desconocidos").

También puedes abrir la carpeta en Android Studio y pulsar **Build → Build APK(s)**, o usar `./gradlew assembleDebug`.

## Novedades de la v1.1.0
- **Logo nuevo** (escudo con los tres perros y la C) como ícono de la app y en pantalla; colores turquesa y gris del logo.
- **Tres puntos animados** mientras Cerberus responde.
- **Clip 📎** con menú: 📷 Cámara · 🖼️ Fotos · 📁 Archivos (texto y PDF).
- **Miniaturas** de las imágenes que subes, antes de enviar y dentro del chat (toca para ampliar).
- **Conversación nueva en cada apertura**; el historial se conserva y se reabre desde ☰.
- **Generadores integrados** de imágenes y videos (ver abajo).

## Generadores
| Módulo | Proveedor | Qué necesitas |
|---|---|---|
| 🖼️ Imágenes | **Pollinations** (por defecto) | Nada: gratis y sin clave (servicio de terceros, puede ir lento o saturarse) |
| 🖼️ Imágenes | **OpenAI** | API Key de OpenAI (modelo por defecto `gpt-image-1`) |
| 🖼️ Imágenes / 🎬 Videos | **Personalizada** | URL de tu API: recibe `POST {"prompt": "..."}` y devuelve `url`, `image`/`video` o `b64` |
| 🎬 Videos | **Replicate** (por defecto) | API Token de replicate.com (modelo por defecto `minimax/video-01`; se cobra por video y tarda minutos) |
| 📝 Guiones y 🎵 TikTok | Modelo de chat | Los ajustes de chat |

Cada proveedor guarda sus propios datos en ⚙️ Configuración. Los resultados se guardan en el teléfono para que el historial no pierda las imágenes y videos.

## Chat
⚙️ Configuración → formato (OpenAI-compatible o Anthropic), URL, API Key y modelo.
- OpenAI: `https://api.openai.com/v1/chat/completions`
- Anthropic: `https://api.anthropic.com/v1/messages`

Las imágenes se envían al modelo si este admite visión. Los PDF se envían como documento (depende del proveedor).

## Archivos
```
app/src/main/java/com/carlosart/cerberusia/
  MainActivity.kt   Entrada
  Ui.kt             Pantallas: chat, historial, configuración, acerca de
  ChatViewModel.kt  Estado, envío, adjuntos, conversación nueva al abrir
  Api.kt            Chat, Pollinations, OpenAI imágenes, Replicate video, API personalizada
  Store.kt          Historial y ajustes (local)
  Models.kt         Datos y módulos
app/src/main/res/drawable-nodpi/   ic_logo.png, ic_launcher_foreground.png
```

## Notas
- El APK es de depuración (firmado con la clave de debug): sirve para instalar y probar. Para Play Store hay que firmar un release con tu propia clave.
- Las API Keys se guardan solo en el teléfono. Para producción es mejor usar un servidor propio como intermediario.
