package com.carlosart.cerberusia

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.ConnectivityManager
import android.net.Network
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.util.UUID
import kotlin.math.max

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    var cfg by mutableStateOf(store.loadCfg())
        private set
    val convs = mutableStateListOf<Conv>()
    var curId by mutableStateOf<String?>(null)
        private set
    var mode by mutableStateOf("chat")
    val pending = mutableStateListOf<Attach>()
    var busyConv by mutableStateOf<String?>(null)
        private set
    var online by mutableStateOf(true)
        private set

    val busy: Boolean get() = busyConv != null
    val current: Conv? get() = convs.firstOrNull { it.id == curId }

    init {
        // El historial se conserva; cada vez que se abre la app empieza una conversación nueva.
        convs.addAll(store.loadConvs().filter { it.msgs.isNotEmpty() })
        newConv()

        val cm = app.getSystemService(ConnectivityManager::class.java)
        online = cm.activeNetwork != null
        cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { online = true }
            override fun onLost(network: Network) { online = false }
        })
    }

    private fun persist() = store.saveConvs(convs)

    fun saveCfg(c: Cfg) {
        cfg = c
        store.saveCfg(c)
    }

    // ───────────── Conversaciones ─────────────

    fun newConv(): Conv {
        current?.takeIf { it.msgs.isEmpty() }?.let { return it }
        val c = Conv(UUID.randomUUID().toString(), "Nueva conversación")
        convs.add(0, c)
        curId = c.id
        return c
    }

    fun select(id: String) {
        curId = id
        convs.removeAll { it.msgs.isEmpty() && it.id != id }
    }

    fun delete(id: String) {
        convs.firstOrNull { it.id == id }?.let { deleteFiles(it) }
        convs.removeAll { it.id == id }
        if (curId == id) curId = null
        if (current == null) newConv()
        persist()
    }

    fun clearAll() {
        convs.forEach { deleteFiles(it) }
        convs.clear()
        curId = null
        newConv()
        persist()
    }

    private fun deleteFiles(c: Conv) {
        c.msgs.forEach { m ->
            val paths = m.thumbs + listOfNotNull(m.mediaUrl?.takeIf { it.startsWith("/") })
            paths.forEach { runCatching { File(it).delete() } }
        }
    }

    // ───────────── Adjuntos ─────────────

    fun addUris(uris: List<Uri>) {
        viewModelScope.launch {
            uris.forEach { uri ->
                val a = withContext(Dispatchers.IO) { runCatching { readAttachment(uri) }.getOrNull() }
                if (a != null) pending.add(a)
            }
        }
    }

    fun removePending(a: Attach) {
        pending.remove(a)
        a.path?.let { runCatching { File(it).delete() } }
    }

    // ───────────── Enviar ─────────────

    fun send(input: String) {
        val text = input.trim()
        if ((text.isEmpty() && pending.isEmpty()) || busy) return
        val conv = current ?: newConv()
        val files = pending.toList()
        pending.clear()

        var full = text
        files.filter { it.text != null }.forEach { full += "\n\n[Archivo: ${it.name}]\n${it.text}" }
        if (full.isBlank()) full = "Analiza el archivo adjunto."
        val prompt = full

        val others = files.filter { !it.isImage }
        val label = text + if (others.isNotEmpty()) "\n" + others.joinToString("\n") { "📎 " + it.name } else ""
        conv.msgs.add(
            Msg("user", label.trim(), thumbs = files.filter { it.isImage }.mapNotNull { it.path })
        )
        if (conv.title == "Nueva conversación") {
            conv.title = text.ifEmpty { files.firstOrNull()?.name ?: "Conversación" }.take(40)
        }

        val history = conv.msgs
            .filter { it.mediaUrl == null && !it.error }
            .map { it.role to it.text }
            .toMutableList()
        history[history.lastIndex] = "user" to prompt

        val module = Modules.byId(mode)
        val snapshot = cfg
        busyConv = conv.id
        persist()

        viewModelScope.launch {
            try {
                if (!online) throw Exception("Sin conexión a internet.")
                val reply = withContext(Dispatchers.IO) {
                    when (module.kind) {
                        Kind.CHAT -> Msg("assistant", Api.chat(snapshot, history, module.system, files))
                        Kind.IMAGE -> mediaMsg(Api.generateImage(snapshot, prompt))
                        Kind.VIDEO -> mediaMsg(Api.generateVideo(snapshot, prompt))
                    }
                }
                conv.msgs.add(reply)
            } catch (e: Exception) {
                conv.msgs.add(Msg("assistant", "⚠️ " + (e.message ?: "Error desconocido"), error = true))
            }
            busyConv = null
            persist()
        }
    }

    /** Guarda el resultado en disco para que el historial lo conserve (las URL de los proveedores caducan). */
    private fun mediaMsg(r: MediaResult): Msg {
        val isVideo = r.kind == Kind.VIDEO
        val dir = File(getApplication<Application>().filesDir, "media").apply { mkdirs() }
        val file = File(dir, "${if (isVideo) "vid" else "img"}_${System.currentTimeMillis()}.${if (isVideo) "mp4" else "png"}")
        val bytes = r.bytes
        val url = r.url
        val path: String? = when {
            bytes != null -> { file.writeBytes(bytes); file.absolutePath }
            url != null -> try {
                Api.downloadTo(url, file)
                file.absolutePath
            } catch (e: Exception) {
                runCatching { file.delete() }
                null
            }
            else -> null
        }
        return Msg("assistant", "Listo ✅", path ?: url, if (isVideo) "video" else "image")
    }

    // ───────────── Lectura de archivos ─────────────

    private fun readUpTo(s: InputStream, limit: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (out.size() < limit) {
            val n = s.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }

    private fun readAttachment(uri: Uri): Attach {
        val cr = getApplication<Application>().contentResolver
        val mime = cr.getType(uri) ?: ""
        var name = "archivo"
        cr.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
        }
        if (mime.startsWith("image/")) return readImage(uri, name)

        if (mime == "application/pdf") {
            val maxPdf = 12_000_000
            val bytes = cr.openInputStream(uri)?.use { readUpTo(it, maxPdf + 1) } ?: ByteArray(0)
            if (bytes.size > maxPdf) return Attach(name, "text/plain", null, "[PDF demasiado grande (máx. 12 MB)]")
            return Attach(name, mime, Base64.encodeToString(bytes, Base64.NO_WRAP), null)
        }

        val bytes = cr.openInputStream(uri)?.use { readUpTo(it, 200_000) } ?: ByteArray(0)
        if (bytes.any { it == 0.toByte() }) {
            return Attach(name, "text/plain", null, "[Archivo binario: no se puede leer como texto]")
        }
        return Attach(name, "text/plain", null, String(bytes, Charsets.UTF_8).take(60_000))
    }

    /** Reduce a máx. 1600 px, corrige la rotación de la cámara y guarda un JPEG local (para la miniatura). */
    private fun readImage(uri: Uri, name: String): Attach {
        val app = getApplication<Application>()
        val cr = app.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp: Bitmap = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return Attach(name, "text/plain", null, "[No se pudo leer la imagen]")

        val orientation: Int = (try {
            cr.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            }
        } catch (e: Exception) {
            null
        }) ?: ExifInterface.ORIENTATION_NORMAL
        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees != 0f) {
            val m = Matrix().apply { postRotate(degrees) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        if (bmp.hasAlpha()) {
            val flat = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(flat)
            canvas.drawColor(android.graphics.Color.WHITE)
            canvas.drawBitmap(bmp, 0f, 0f, null)
            bmp = flat
        }

        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
        val bytes = out.toByteArray()
        val dir = File(app.filesDir, "uploads").apply { mkdirs() }
        val file = File(dir, "up_${System.nanoTime()}.jpg")
        file.writeBytes(bytes)
        return Attach(name, "image/jpeg", Base64.encodeToString(bytes, Base64.NO_WRAP), null, file.absolutePath)
    }
}
