package com.carlosart.cerberusia

import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.io.File

enum class Screen { Chat, Settings, About }

@Composable
fun CerberusApp(vm: ChatViewModel = viewModel()) {
    var screen by remember { mutableStateOf(Screen.Chat) }
    BackHandler(enabled = screen != Screen.Chat) {
        screen = if (screen == Screen.About) Screen.Settings else Screen.Chat
    }
    when (screen) {
        Screen.Chat -> ChatScreen(vm, onSettings = { screen = Screen.Settings })
        Screen.Settings -> SettingsScreen(
            vm,
            onBack = { screen = Screen.Chat },
            onAbout = { screen = Screen.About }
        )
        Screen.About -> AboutScreen(onBack = { screen = Screen.Settings })
    }
}

// ───────────────────────── Chat ─────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatViewModel, onSettings: () -> Unit) {
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    var showAttach by remember { mutableStateOf(false) }
    var camUri by rememberSaveable { mutableStateOf<Uri?>(null) }

    val photos = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        vm.addUris(uris)
    }
    val files = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        vm.addUris(uris)
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = camUri
        if (ok && u != null) vm.addUris(listOf(u))
    }

    fun takePhoto() {
        try {
            val dir = File(ctx.cacheDir, "camera").apply { mkdirs() }
            val f = File(dir, "photo_${System.currentTimeMillis()}.jpg")
            val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
            camUri = u
            camera.launch(u)
        } catch (e: Exception) {
            // No hay app de cámara disponible
        }
    }

    BackHandler(enabled = drawer.isOpen) { scope.launch { drawer.close() } }

    val conv = vm.current
    val listState = rememberLazyListState()
    val count = conv?.msgs?.size ?: 0
    val typing = vm.busyConv != null && vm.busyConv == conv?.id
    LaunchedEffect(count, typing, conv?.id) {
        val total = count + if (typing) 1 else 0
        if (total > 0) listState.animateScrollToItem(total - 1)
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = { HistoryDrawer(vm, close = { scope.launch { drawer.close() } }) }
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawer.open() } }) { Text("☰", fontSize = 20.sp) }
                    },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(painterResource(R.drawable.ic_logo), null, Modifier.size(34.dp))
                            Spacer(Modifier.size(8.dp))
                            Text("Cerberus IA")
                            Spacer(Modifier.size(8.dp))
                            Box(
                                Modifier.size(9.dp).clip(CircleShape)
                                    .background(if (vm.online) Color(0xFF22C55E) else Color.Gray)
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = { vm.newConv() }) { Text("✏️", fontSize = 20.sp) }
                        IconButton(onClick = onSettings) { Text("⚙️", fontSize = 20.sp) }
                    }
                )
            },
            bottomBar = {
                Column(
                    Modifier.background(MaterialTheme.colorScheme.surface).imePadding().navigationBarsPadding()
                ) {
                    ModeBar(vm)
                    PendingFiles(vm)
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.Bottom
                    ) {
                        IconButton(onClick = { showAttach = true }) { Text("📎", fontSize = 22.sp) }
                        OutlinedTextField(
                            value = input,
                            onValueChange = { input = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("Escribe a Cerberus…") },
                            maxLines = 5,
                            shape = RoundedCornerShape(24.dp)
                        )
                        Spacer(Modifier.size(6.dp))
                        FilledIconButton(
                            onClick = { vm.send(input); input = "" },
                            enabled = !vm.busy,
                            modifier = Modifier.size(48.dp)
                        ) { Text("➤", fontSize = 18.sp) }
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                if (conv == null || (conv.msgs.isEmpty() && !typing)) {
                    Welcome(onPick = { vm.send(it) })
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(conv.msgs) { m -> Bubble(m) }
                        if (typing) {
                            item { TypingBubble() }
                        }
                    }
                }
            }
        }
    }

    if (showAttach) {
        ModalBottomSheet(onDismissRequest = { showAttach = false }) {
            Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 24.dp).navigationBarsPadding()) {
                AttachRow("📷", "Cámara", "Tomar una foto") {
                    showAttach = false
                    takePhoto()
                }
                AttachRow("🖼️", "Fotos", "Elegir de tu galería") {
                    showAttach = false
                    photos.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                AttachRow("📁", "Archivos", "Documentos, PDF, texto…") {
                    showAttach = false
                    files.launch(arrayOf("*/*"))
                }
            }
        }
    }
}

@Composable
private fun AttachRow(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(icon, fontSize = 26.sp)
        Spacer(Modifier.size(16.dp))
        Column {
            Text(title, fontSize = 16.sp)
            Text(subtitle, color = CerberusMuted, fontSize = 13.sp)
        }
    }
}

@Composable
fun Welcome(onPick: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(painterResource(R.drawable.ic_logo), null, Modifier.size(130.dp))
        Spacer(Modifier.height(8.dp))
        Text("Hola, soy Cerberus IA", fontSize = 22.sp)
        Text("Creado por CarlosArt", color = CerberusMuted)
        Spacer(Modifier.height(16.dp))
        listOf("¿Quién te creó?", "Dame ideas de contenido para esta semana", "Explícame algo interesante").forEach {
            AssistChip(onClick = { onPick(it) }, label = { Text(it) }, modifier = Modifier.padding(vertical = 3.dp))
        }
    }
}

@Composable
fun ModeBar(vm: ChatViewModel) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Modules.all.forEach { m ->
            FilterChip(
                selected = vm.mode == m.id,
                onClick = { vm.mode = m.id },
                label = { Text(m.icon + " " + m.name) }
            )
        }
    }
}

/** Adjuntos pendientes: las imágenes se ven en miniatura. */
@Composable
fun PendingFiles(vm: ChatViewModel) {
    if (vm.pending.isEmpty()) return
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        vm.pending.toList().forEach { a ->
            val p = a.path
            if (a.isImage && p != null) {
                Box {
                    AsyncImage(
                        model = File(p),
                        contentDescription = a.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(68.dp).clip(RoundedCornerShape(12.dp))
                    )
                    Box(
                        Modifier.align(Alignment.TopEnd).padding(3.dp).size(22.dp).clip(CircleShape)
                            .background(Color(0xCC000000)).clickable { vm.removePending(a) },
                        contentAlignment = Alignment.Center
                    ) { Text("✕", fontSize = 11.sp, color = Color.White) }
                }
            } else {
                AssistChip(onClick = { vm.removePending(a) }, label = { Text("📎 ${a.name.take(22)} ✕") })
            }
        }
    }
}

/** Tres puntos animados mientras Cerberus responde. */
@Composable
fun TypingDots() {
    val transition = rememberInfiniteTransition(label = "dots")
    Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.height(18.dp)
    ) {
        repeat(3) { i ->
            val a by transition.animateFloat(
                initialValue = 0.25f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(450, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse,
                    initialStartOffset = StartOffset(i * 150)
                ),
                label = "dot$i"
            )
            Box(
                Modifier.size(10.dp)
                    .graphicsLayer {
                        alpha = a
                        scaleX = 0.7f + 0.3f * a
                        scaleY = 0.7f + 0.3f * a
                    }
                    .clip(CircleShape)
                    .background(Teal)
            )
        }
    }
}

@Composable
fun TypingBubble() {
    Row(Modifier.fillMaxWidth()) {
        Box(
            Modifier.background(
                MaterialTheme.colorScheme.surfaceVariant,
                RoundedCornerShape(16.dp, 16.dp, 16.dp, 4.dp)
            ).padding(horizontal = 18.dp, vertical = 14.dp)
        ) { TypingDots() }
    }
}

@Composable
fun Bubble(m: Msg) {
    val user = m.role == "user"
    var zoom by remember { mutableStateOf<Any?>(null) }
    val shape = RoundedCornerShape(16.dp, 16.dp, if (user) 4.dp else 16.dp, if (user) 16.dp else 4.dp)
    val bg = if (user) {
        Modifier.background(Brush.linearGradient(listOf(Teal, TealDark)), shape)
    } else {
        Modifier.background(MaterialTheme.colorScheme.surfaceVariant, shape)
    }
    val fg = if (user) OnTeal else MaterialTheme.colorScheme.onSurface

    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (user) Arrangement.End else Arrangement.Start
    ) {
        Column(Modifier.widthIn(max = 320.dp).then(bg).padding(10.dp)) {
            if (m.thumbs.isNotEmpty()) {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    m.thumbs.forEach { path ->
                        AsyncImage(
                            model = File(path),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.size(96.dp).clip(RoundedCornerShape(12.dp))
                                .clickable { zoom = File(path) }
                        )
                    }
                }
                if (m.text.isNotBlank()) Spacer(Modifier.height(6.dp))
            }
            if (m.text.isNotBlank()) {
                SelectionContainer { Text(m.text, color = fg) }
            }
            val url = m.mediaUrl
            if (url != null) {
                if (m.mediaType == "video") {
                    VideoPlayer(url)
                } else {
                    val model: Any = if (url.startsWith("/")) File(url) else url
                    AsyncImage(
                        model = model,
                        contentDescription = null,
                        contentScale = ContentScale.FillWidth,
                        modifier = Modifier.padding(top = 8.dp).fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .clickable { zoom = model }
                    )
                }
            }
        }
    }

    val z = zoom
    if (z != null) {
        Dialog(onDismissRequest = { zoom = null }) {
            AsyncImage(
                model = z,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { zoom = null }
            )
        }
    }
}

@Composable
fun VideoPlayer(src: String) {
    AndroidView(
        modifier = Modifier.padding(top = 8.dp).fillMaxWidth().height(200.dp).clip(RoundedCornerShape(12.dp)),
        factory = { c ->
            VideoView(c).apply {
                val mc = MediaController(c)
                mc.setAnchorView(this)
                setMediaController(mc)
                if (src.startsWith("/")) setVideoPath(src) else setVideoURI(Uri.parse(src))
                setOnPreparedListener { seekTo(100) }
            }
        }
    )
}

@Composable
fun HistoryDrawer(vm: ChatViewModel, close: () -> Unit) {
    var toDelete by remember { mutableStateOf<Conv?>(null) }
    val saved = vm.convs.filter { it.msgs.isNotEmpty() }
    ModalDrawerSheet {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.ic_logo), null, Modifier.size(32.dp))
                Spacer(Modifier.size(8.dp))
                Text("Historial", fontSize = 18.sp)
            }
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { vm.newConv(); close() },
                modifier = Modifier.fillMaxWidth()
            ) { Text("✏️ Nueva conversación") }
            Spacer(Modifier.height(8.dp))
            HorizontalDivider()
            if (saved.isEmpty()) {
                Text("Aún no hay conversaciones.", color = CerberusMuted, modifier = Modifier.padding(top = 12.dp))
            }
            LazyColumn {
                items(saved, key = { it.id }) { c ->
                    NavigationDrawerItem(
                        label = { Text(c.title, maxLines = 1) },
                        selected = c.id == vm.curId,
                        onClick = { vm.select(c.id); close() },
                        badge = { IconButton(onClick = { toDelete = c }) { Text("🗑️") } }
                    )
                }
            }
        }
    }
    val del = toDelete
    if (del != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("¿Borrar conversación?") },
            text = { Text(del.title) },
            confirmButton = { TextButton(onClick = { vm.delete(del.id); toDelete = null }) { Text("Borrar") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } }
        )
    }
}

// ───────────────────────── Configuración ─────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: ChatViewModel, onBack: () -> Unit, onAbout: () -> Unit) {
    val c = vm.cfg
    var format by remember { mutableStateOf(c.format) }
    var url by remember { mutableStateOf(c.url) }
    var key by remember { mutableStateOf(c.key) }
    var model by remember { mutableStateOf(c.model) }
    var system by remember { mutableStateOf(c.system) }
    var imgProvider by remember { mutableStateOf(c.imgProvider) }
    var vidProvider by remember { mutableStateOf(c.vidProvider) }
    val imgStore = remember { mutableStateMapOf<String, ProviderCfg>().apply { putAll(c.img) } }
    val vidStore = remember { mutableStateMapOf<String, ProviderCfg>().apply { putAll(c.vid) } }
    var confirmClear by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
                navigationIcon = { IconButton(onClick = onBack) { Text("←", fontSize = 22.sp) } },
                title = { Text("⚙️ Configuración") }
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
                .imePadding(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("🤖 Modelo de chat", fontSize = 18.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = format == "openai", onClick = { format = "openai" }, label = { Text("Compatible OpenAI") })
                FilterChip(selected = format == "anthropic", onClick = { format = "anthropic" }, label = { Text("Anthropic") })
            }
            Field("URL de la API", url, { url = it }, "https://api.openai.com/v1/chat/completions")
            Field("API Key", key, { key = it }, "sk-…", secret = true)
            Field("Modelo", model, { model = it }, "gpt-4o-mini / claude-sonnet-4-5")
            Field("Instrucciones extra del sistema (opcional)", system, { system = it }, "", single = false)

            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            Text("🖼️ Generador de imágenes", fontSize = 18.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    Providers.IMG_POLLINATIONS to "Pollinations (gratis)",
                    Providers.IMG_OPENAI to "OpenAI",
                    Providers.IMG_CUSTOM to "Personalizada"
                ).forEach { (id, label) ->
                    FilterChip(selected = imgProvider == id, onClick = { imgProvider = id }, label = { Text(label) })
                }
            }
            when (imgProvider) {
                Providers.IMG_POLLINATIONS -> {
                    Hint("Funciona sin clave y sin registro. Es un servicio gratuito de terceros: puede ir lento o saturarse.")
                    PModel(imgStore, imgProvider, "Modelo (opcional)", "flux")
                }
                Providers.IMG_OPENAI -> {
                    Hint("Usa tu cuenta de OpenAI (se cobra por imagen).")
                    PKey(imgStore, imgProvider, "API Key de OpenAI")
                    PModel(imgStore, imgProvider, "Modelo (opcional)", "gpt-image-1")
                    PUrl(imgStore, imgProvider, "URL (opcional)", "https://api.openai.com/v1/images/generations")
                }
                else -> {
                    Hint("Tu propia API: recibe POST {\"prompt\": \"...\"} y devuelve url, image o b64.")
                    PUrl(imgStore, imgProvider, "URL", "https://tu-api/imagenes")
                    PKey(imgStore, imgProvider, "API Key (opcional)")
                }
            }

            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            Text("🎬 Generador de videos", fontSize = 18.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    Providers.VID_REPLICATE to "Replicate",
                    Providers.VID_CUSTOM to "Personalizada"
                ).forEach { (id, label) ->
                    FilterChip(selected = vidProvider == id, onClick = { vidProvider = id }, label = { Text(label) })
                }
            }
            when (vidProvider) {
                Providers.VID_REPLICATE -> {
                    Hint("Crea tu API token en replicate.com (se cobra por video; tarda desde 1 hasta varios minutos).")
                    PKey(vidStore, vidProvider, "API Token de Replicate")
                    PModel(vidStore, vidProvider, "Modelo de video (opcional)", "minimax/video-01")
                }
                else -> {
                    Hint("Tu propia API: recibe POST {\"prompt\": \"...\"} y devuelve la url del video.")
                    PUrl(vidStore, vidProvider, "URL", "https://tu-api/videos")
                    PKey(vidStore, vidProvider, "API Key (opcional)")
                }
            }
            Hint("Guiones y TikTok usan el modelo de chat.")

            Button(
                onClick = {
                    vm.saveCfg(
                        Cfg(
                            format = format,
                            url = url.trim(),
                            key = key.trim(),
                            model = model.trim(),
                            system = system.trim(),
                            imgProvider = imgProvider,
                            vidProvider = vidProvider,
                            img = imgStore.mapValues { it.value.trimmed() },
                            vid = vidStore.mapValues { it.value.trimmed() }
                        )
                    )
                    onBack()
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Guardar") }
            OutlinedButton(onClick = onAbout, modifier = Modifier.fillMaxWidth()) { Text("ℹ️ Acerca de Cerberus") }
            OutlinedButton(onClick = { confirmClear = true }, modifier = Modifier.fillMaxWidth()) { Text("Borrar historial") }
            Spacer(Modifier.height(24.dp))
        }
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("¿Borrar todo el historial?") },
            confirmButton = { TextButton(onClick = { vm.clearAll(); confirmClear = false; onBack() }) { Text("Borrar") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun Hint(text: String) {
    Text(text, color = CerberusMuted, fontSize = 12.sp)
}

@Composable
private fun PUrl(s: SnapshotStateMap<String, ProviderCfg>, p: String, label: String, hint: String) {
    Field(label, (s[p] ?: ProviderCfg()).url, { v -> s[p] = (s[p] ?: ProviderCfg()).copy(url = v) }, hint)
}

@Composable
private fun PKey(s: SnapshotStateMap<String, ProviderCfg>, p: String, label: String) {
    Field(label, (s[p] ?: ProviderCfg()).key, { v -> s[p] = (s[p] ?: ProviderCfg()).copy(key = v) }, "", secret = true)
}

@Composable
private fun PModel(s: SnapshotStateMap<String, ProviderCfg>, p: String, label: String, hint: String) {
    Field(label, (s[p] ?: ProviderCfg()).model, { v -> s[p] = (s[p] ?: ProviderCfg()).copy(model = v) }, hint)
}

@Composable
private fun Field(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    secret: Boolean = false,
    single: Boolean = true
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        placeholder = { if (hint.isNotEmpty()) Text(hint) },
        singleLine = single,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        modifier = Modifier.fillMaxWidth()
    )
}

// ───────────────────────── Acerca de ─────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(onBack: () -> Unit) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
                navigationIcon = { IconButton(onClick = onBack) { Text("←", fontSize = 22.sp) } },
                title = { Text("Acerca de Cerberus") }
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(painterResource(R.drawable.ic_logo), null, Modifier.size(160.dp))
            Spacer(Modifier.height(8.dp))
            Text("Cerberus IA", fontSize = 24.sp)
            Text("Versión 1.1.0", color = CerberusMuted)
            Spacer(Modifier.height(16.dp))
            Text("Asistente de inteligencia artificial creado por CarlosArt.", textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Text(
                "Chat con conexión online, historial, adjuntos y módulos para generar imágenes, videos, " +
                    "guiones y contenido para TikTok.",
                color = CerberusMuted, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            Text("© 2026 CarlosArt. Todos los derechos reservados.", color = CerberusMuted, fontSize = 12.sp)
        }
    }
}
