package com.carlosart.cerberusia

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Persistencia local simple (SharedPreferences + JSON). */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("cerberus", Context.MODE_PRIVATE)

    fun loadCfg(): Cfg = Cfg(
        format = p.getString("format", "openai") ?: "openai",
        url = p.getString("url", "") ?: "",
        key = p.getString("key", "") ?: "",
        model = p.getString("model", "") ?: "",
        system = p.getString("system", "") ?: "",
        imgProvider = p.getString("imgProvider", Providers.IMG_POLLINATIONS) ?: Providers.IMG_POLLINATIONS,
        vidProvider = p.getString("vidProvider", Providers.VID_REPLICATE) ?: Providers.VID_REPLICATE,
        img = decode(p.getString("img", null)),
        vid = decode(p.getString("vid", null))
    )

    fun saveCfg(c: Cfg) {
        p.edit()
            .putString("format", c.format)
            .putString("url", c.url)
            .putString("key", c.key)
            .putString("model", c.model)
            .putString("system", c.system)
            .putString("imgProvider", c.imgProvider)
            .putString("vidProvider", c.vidProvider)
            .putString("img", encode(c.img))
            .putString("vid", encode(c.vid))
            .apply()
    }

    private fun encode(m: Map<String, ProviderCfg>): String {
        val o = JSONObject()
        m.forEach { (k, v) ->
            o.put(k, JSONObject().put("url", v.url).put("key", v.key).put("model", v.model))
        }
        return o.toString()
    }

    private fun decode(s: String?): Map<String, ProviderCfg> {
        if (s.isNullOrBlank()) return emptyMap()
        return try {
            val o = JSONObject(s)
            o.keys().asSequence().associateWith { k ->
                val x = o.getJSONObject(k)
                ProviderCfg(x.optString("url"), x.optString("key"), x.optString("model"))
            }
        } catch (e: Exception) {
            emptyMap()
        }
    }

    fun loadConvs(): List<Conv> {
        val raw = p.getString("convs", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val c = Conv(o.getString("id"), o.optString("title", "Conversación"))
                val ms = o.optJSONArray("msgs") ?: JSONArray()
                for (j in 0 until ms.length()) {
                    val m = ms.getJSONObject(j)
                    val th = m.optJSONArray("th")
                    c.msgs.add(
                        Msg(
                            role = m.optString("r", "assistant"),
                            text = m.optString("t", ""),
                            mediaUrl = if (m.isNull("mu")) null else m.optString("mu"),
                            mediaType = if (m.isNull("mt")) null else m.optString("mt"),
                            thumbs = if (th == null) emptyList() else (0 until th.length()).map { th.getString(it) },
                            error = m.optBoolean("e", false)
                        )
                    )
                }
                c
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Las conversaciones vacías no se guardan. */
    fun saveConvs(list: List<Conv>) {
        val arr = JSONArray()
        list.filter { it.msgs.isNotEmpty() }.forEach { c ->
            val ms = JSONArray()
            c.msgs.forEach { m ->
                ms.put(
                    JSONObject()
                        .put("r", m.role)
                        .put("t", m.text)
                        .put("mu", m.mediaUrl ?: JSONObject.NULL)
                        .put("mt", m.mediaType ?: JSONObject.NULL)
                        .put("th", JSONArray(m.thumbs))
                        .put("e", m.error)
                )
            }
            arr.put(JSONObject().put("id", c.id).put("title", c.title).put("msgs", ms))
        }
        p.edit().putString("convs", arr.toString()).apply()
    }
}
