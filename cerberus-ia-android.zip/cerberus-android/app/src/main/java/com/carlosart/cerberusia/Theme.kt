package com.carlosart.cerberusia

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Colores tomados del logo: turquesa y gris pizarra.
val Teal = Color(0xFF3FE0D0)
val TealDark = Color(0xFF1FA89B)
val OnTeal = Color(0xFF04201D)
val CerberusBg = Color(0xFF0E1214)
val CerberusPanel = Color(0xFF151B1E)
val CerberusPanel2 = Color(0xFF1E2629)
val CerberusMuted = Color(0xFF8DA0A6)

private val Scheme = darkColorScheme(
    primary = Teal,
    onPrimary = OnTeal,
    secondary = TealDark,
    secondaryContainer = Color(0xFF15423D),
    onSecondaryContainer = Color(0xFFD8FFFA),
    background = CerberusBg,
    onBackground = Color(0xFFECF3F4),
    surface = CerberusPanel,
    onSurface = Color(0xFFECF3F4),
    surfaceVariant = CerberusPanel2,
    onSurfaceVariant = Color(0xFFECF3F4),
    surfaceContainerLowest = CerberusBg,
    surfaceContainerLow = CerberusPanel,
    surfaceContainer = CerberusPanel,
    surfaceContainerHigh = CerberusPanel2,
    surfaceContainerHighest = CerberusPanel2,
    outline = Color(0xFF3A474C),
    outlineVariant = Color(0xFF2B363A)
)

@Composable
fun CerberusTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
