package com.carlosart.cerberusia

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class Msg(
    val role: String,                  // "user" | "assistant"
    val text: String,
    val mediaUrl: String? = null,      // ruta local o URL del resultado generado
    val mediaType: String? = null,     // "image" | "video"
    val thumbs: List<String> = emptyList(), // rutas locales de las imágenes que subió el usuario
    val error: Boolean = false
)

class Conv(val id: String, initialTitle: String) {
    var title by mutableStateOf(initialTitle)
    val msgs = mutableStateListOf<Msg>()
}

object Providers {
    const val IMG_POLLINATIONS = "pollinations"
    const val IMG_OPENAI = "openai"
    const val IMG_CUSTOM = "custom"
    const val VID_REPLICATE = "replicate"
    const val VID_CUSTOM = "custom"
}

/** Ajustes de un proveedor de imágenes o videos (cada uno guarda sus propios datos). */
data class ProviderCfg(val url: String = "", val key: String = "", val model: String = "") {
    fun trimmed() = ProviderCfg(url.trim(), key.trim(), model.trim())
}

data class Cfg(
    val format: String = "openai",   // "openai" | "anthropic"
    val url: String = "",
    val key: String = "",
    val model: String = "",
    val system: String = "",
    val imgProvider: String = Providers.IMG_POLLINATIONS,
    val vidProvider: String = Providers.VID_REPLICATE,
    val img: Map<String, ProviderCfg> = emptyMap(),
    val vid: Map<String, ProviderCfg> = emptyMap()
) {
    val imgCfg: ProviderCfg get() = img[imgProvider] ?: ProviderCfg()
    val vidCfg: ProviderCfg get() = vid[vidProvider] ?: ProviderCfg()
}

/** Adjunto: imagen (b64 + ruta local para la miniatura), PDF (b64) o texto. */
data class Attach(
    val name: String,
    val mime: String,
    val b64: String?,
    val text: String?,
    val path: String? = null
) {
    val isImage: Boolean get() = mime.startsWith("image/") && b64 != null
    val isPdf: Boolean get() = mime == "application/pdf" && b64 != null
}

enum class Kind { CHAT, IMAGE, VIDEO }

/** Arquitectura de módulos: agrega aquí nuevos generadores. */
data class AiModule(
    val id: String,
    val icon: String,
    val name: String,
    val kind: Kind,
    val system: String = ""
)

object Modules {
    val all = listOf(
        AiModule("chat", "💬", "Chat", Kind.CHAT),
        AiModule(
            "script", "📝", "Guiones", Kind.CHAT,
            "Modo GENERADOR DE GUIONES: escribe guiones profesionales (video, YouTube, anuncios, cortos) " +
                "con estructura clara: gancho, desarrollo, cierre, indicaciones de escena y diálogos. " +
                "Pregunta solo lo imprescindible."
        ),
        AiModule(
            "tiktok", "🎵", "TikTok", Kind.CHAT,
            "Modo GENERADOR AUTOMÁTICO DE CONTENIDO PARA TIKTOK: con solo un tema, entrega un paquete listo: " +
                "3 ideas de gancho (primeros 3 segundos), guion de 15-45 s con tiempos, texto en pantalla, " +
                "sugerencias de tomas, audio o tendencia sugerida, caption, 8 hashtags y mejor hora para publicar."
        ),
        AiModule("image", "🖼️", "Imágenes", Kind.IMAGE),
        AiModule("video", "🎬", "Videos", Kind.VIDEO)
    )

    fun byId(id: String): AiModule = all.firstOrNull { it.id == id } ?: all.first()
}
