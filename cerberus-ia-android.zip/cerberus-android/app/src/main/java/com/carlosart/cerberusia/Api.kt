package com.carlosart.cerberusia

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Resultado de un generador: una URL remota o los bytes ya descargados. */
class MediaResult(val kind: Kind, val url: String?, val bytes: ByteArray?)

/** Llamadas de red. Ejecutar siempre fuera del hilo principal. */
object Api {
    const val CREATOR =
        "Eres Cerberus IA, un asistente de inteligencia artificial moderno y útil. " +
            "Fuiste creado por CarlosArt. Si te preguntan quién te creó, quién te hizo o de quién eres, " +
            "responde siempre que fuiste creado por CarlosArt. Responde en el idioma del usuario."

    // ───────────── HTTP básico ─────────────

    private fun request(method: String, url: String, headers: Map<String, String>, body: String?): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 30_000
            c.readTimeout = 180_000
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val data = stream?.use { it.readBytes() } ?: ByteArray(0)
            if (code !in 200..299) throw Exception(errorMessage(String(data, Charsets.UTF_8), code))
            return data
        } finally {
            c.disconnect()
        }
    }

    private fun postJson(url: String, headers: Map<String, String>, body: String): String =
        String(request("POST", url, headers, body), Charsets.UTF_8)

    private fun errorMessage(text: String, code: Int): String = try {
        val j = JSONObject(text)
        val e = j.opt("error")
        when {
            e is JSONObject && e.optString("message").isNotBlank() -> e.optString("message")
            e is String && e.isNotBlank() -> e
            j.optString("detail").isNotBlank() -> j.optString("detail")
            else -> "Error $code"
        }
    } catch (e: Exception) {
        "Error $code"
    }

    /** Descarga un archivo remoto a disco (para que el historial conserve imágenes y videos). */
    fun downloadTo(url: String, dest: File) {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 30_000
            c.readTimeout = 120_000
            if (c.responseCode !in 200..299) throw Exception("Error ${c.responseCode}")
            c.inputStream.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        } finally {
            c.disconnect()
        }
    }

    // ───────────── Chat ─────────────

    /** history: pares (rol, texto); el último es el mensaje nuevo del usuario. */
    fun chat(cfg: Cfg, history: List<Pair<String, String>>, extraSystem: String, files: List<Attach>): String {
        if (cfg.url.isBlank() || cfg.key.isBlank() || cfg.model.isBlank()) {
            throw Exception("Configura la URL, API Key y modelo en ⚙️ Configuración.")
        }
        val system = listOf(CREATOR, extraSystem, cfg.system).filter { it.isNotBlank() }.joinToString("\n\n")
        val images = files.filter { it.isImage }
        val pdfs = files.filter { it.isPdf }
        val prior = history.dropLast(1)
        val lastText = history.last().second

        if (cfg.format == "anthropic") {
            val msgs = JSONArray()
            prior.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
            val content = JSONArray()
            images.forEach {
                content.put(
                    JSONObject().put("type", "image").put(
                        "source",
                        JSONObject().put("type", "base64").put("media_type", it.mime).put("data", it.b64)
                    )
                )
            }
            pdfs.forEach {
                content.put(
                    JSONObject().put("type", "document").put(
                        "source",
                        JSONObject().put("type", "base64").put("media_type", "application/pdf").put("data", it.b64)
                    )
                )
            }
            content.put(JSONObject().put("type", "text").put("text", lastText))
            msgs.put(JSONObject().put("role", "user").put("content", content))
            val body = JSONObject()
                .put("model", cfg.model)
                .put("max_tokens", 4096)
                .put("system", system)
                .put("messages", msgs)
            val res = JSONObject(
                postJson(
                    cfg.url,
                    mapOf("x-api-key" to cfg.key, "anthropic-version" to "2023-06-01"),
                    body.toString()
                )
            )
            val arr = res.getJSONArray("content")
            return buildString { for (i in 0 until arr.length()) append(arr.getJSONObject(i).optString("text")) }
        }

        // Formato compatible con OpenAI
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", system))
        prior.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        val lastContent: Any = if (images.isEmpty() && pdfs.isEmpty()) {
            lastText
        } else {
            val arr = JSONArray()
            arr.put(JSONObject().put("type", "text").put("text", lastText))
            images.forEach {
                arr.put(
                    JSONObject().put("type", "image_url")
                        .put("image_url", JSONObject().put("url", "data:${it.mime};base64,${it.b64}"))
                )
            }
            pdfs.forEach {
                arr.put(
                    JSONObject().put("type", "file").put(
                        "file",
                        JSONObject().put("filename", it.name)
                            .put("file_data", "data:application/pdf;base64,${it.b64}")
                    )
                )
            }
            arr
        }
        msgs.put(JSONObject().put("role", "user").put("content", lastContent))
        val body = JSONObject().put("model", cfg.model).put("messages", msgs)
        val res = JSONObject(postJson(cfg.url, mapOf("Authorization" to "Bearer ${cfg.key}"), body.toString()))
        return res.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
    }

    // ───────────── Generador de imágenes ─────────────

    fun generateImage(cfg: Cfg, prompt: String): MediaResult = when (cfg.imgProvider) {
        Providers.IMG_OPENAI -> openAiImage(cfg.imgCfg, prompt)
        Providers.IMG_CUSTOM -> custom(Kind.IMAGE, cfg.imgCfg, prompt)
        else -> pollinations(cfg.imgCfg, prompt)
    }

    /** Pollinations: gratis y sin clave (GET con el prompt en la URL). */
    private fun pollinations(p: ProviderCfg, prompt: String): MediaResult {
        val model = p.model.ifBlank { "flux" }
        val q = URLEncoder.encode(prompt.take(1500), "UTF-8").replace("+", "%20")
        val url = "https://image.pollinations.ai/prompt/$q?width=1024&height=1024&nologo=true" +
            "&model=${URLEncoder.encode(model, "UTF-8")}&seed=${(0..999_999).random()}"
        val bytes = try {
            request("GET", url, emptyMap(), null)
        } catch (e: Exception) {
            throw Exception(
                "No se pudo generar la imagen con Pollinations (${e.message}). " +
                    "Si el servicio está saturado o ahora pide clave, prueba otro proveedor en ⚙️ Configuración."
            )
        }
        if (!looksLikeImage(bytes)) {
            throw Exception("Pollinations no devolvió una imagen. Prueba otro proveedor en ⚙️ Configuración.")
        }
        return MediaResult(Kind.IMAGE, null, bytes)
    }

    private fun looksLikeImage(b: ByteArray): Boolean {
        if (b.size < 12) return false
        val jpg = b[0] == 0xFF.toByte() && b[1] == 0xD8.toByte()
        val png = b[0] == 0x89.toByte() && b[1] == 'P'.code.toByte()
        val webp = b[0] == 'R'.code.toByte() && b[1] == 'I'.code.toByte() && b[8] == 'W'.code.toByte()
        return jpg || png || webp
    }

    /** OpenAI (o compatible): POST /v1/images/generations. */
    private fun openAiImage(p: ProviderCfg, prompt: String): MediaResult {
        if (p.key.isBlank()) throw Exception("Agrega tu API Key de OpenAI para imágenes en ⚙️ Configuración.")
        val url = p.url.ifBlank { "https://api.openai.com/v1/images/generations" }
        val body = JSONObject()
            .put("model", p.model.ifBlank { "gpt-image-1" })
            .put("prompt", prompt)
            .put("size", "1024x1024")
        val j = JSONObject(postJson(url, mapOf("Authorization" to "Bearer ${p.key}"), body.toString()))
        return parseMedia(Kind.IMAGE, j)
    }

    // ───────────── Generador de videos ─────────────

    fun generateVideo(cfg: Cfg, prompt: String): MediaResult =
        if (cfg.vidProvider == Providers.VID_CUSTOM) custom(Kind.VIDEO, cfg.vidCfg, prompt)
        else replicateVideo(cfg.vidCfg, prompt)

    /**
     * Replicate: crea la predicción y espera el resultado consultando su estado.
     * Modelo "dueño/nombre" (oficial) o "dueño/nombre:versión" (comunidad).
     */
    private fun replicateVideo(p: ProviderCfg, prompt: String): MediaResult {
        if (p.key.isBlank()) throw Exception("Agrega tu API Key de Replicate en ⚙️ Configuración.")
        val slug = p.model.trim().ifBlank { "minimax/video-01" }
        val auth = mapOf("Authorization" to "Bearer ${p.key}")
        val input = JSONObject().put("prompt", prompt)
        val endpoint: String
        val body: JSONObject
        if (slug.contains(":")) {
            endpoint = "https://api.replicate.com/v1/predictions"
            body = JSONObject().put("version", slug.substringAfter(":")).put("input", input)
        } else {
            endpoint = "https://api.replicate.com/v1/models/$slug/predictions"
            body = JSONObject().put("input", input)
        }
        var pred = JSONObject(postJson(endpoint, auth + ("Prefer" to "wait=30"), body.toString()))
        val getUrl = pred.optJSONObject("urls")?.optString("get") ?: ""
        val deadline = System.currentTimeMillis() + 8 * 60_000L
        while (true) {
            when (pred.optString("status")) {
                "succeeded", "successful" -> {
                    val out = pred.opt("output")
                    val link = when (out) {
                        is String -> out
                        is JSONArray -> out.optString(0)
                        else -> ""
                    }
                    if (!link.startsWith("http")) throw Exception("Replicate no devolvió un video.")
                    return MediaResult(Kind.VIDEO, link, null)
                }
                "failed", "canceled" ->
                    throw Exception(pred.optString("error").takeIf { it.isNotBlank() && it != "null" }
                        ?: "La generación de video falló.")
            }
            if (getUrl.isBlank()) throw Exception("Respuesta inesperada de Replicate.")
            if (System.currentTimeMillis() > deadline) {
                throw Exception("La generación de video tardó demasiado. Inténtalo de nuevo.")
            }
            Thread.sleep(3_000)
            pred = JSONObject(String(request("GET", getUrl, auth, null), Charsets.UTF_8))
        }
    }

    // ───────────── API personalizada y utilidades ─────────────

    /** POST {"prompt": "..."} a la URL del usuario. */
    private fun custom(kind: Kind, p: ProviderCfg, prompt: String): MediaResult {
        if (p.url.isBlank()) throw Exception("Agrega la URL de tu API en ⚙️ Configuración.")
        val headers = if (p.key.isNotBlank()) mapOf("Authorization" to "Bearer ${p.key}") else emptyMap()
        return parseMedia(kind, JSONObject(postJson(p.url, headers, JSONObject().put("prompt", prompt).toString())))
    }

    private fun parseMedia(kind: Kind, j: JSONObject): MediaResult {
        val d0 = j.optJSONArray("data")?.optJSONObject(0)
        val link = listOf(
            j.optString("url"), j.optString("image"), j.optString("video"),
            j.optString("output"), d0?.optString("url") ?: ""
        ).firstOrNull { it.startsWith("http") }
        if (link != null) return MediaResult(kind, link, null)
        val b64 = j.optString("b64").ifBlank { d0?.optString("b64_json") ?: "" }
        if (b64.isNotBlank()) {
            return MediaResult(kind, null, Base64.decode(b64.substringAfter("base64,"), Base64.DEFAULT))
        }
        throw Exception("La API no devolvió una URL ni una imagen/video reconocible.")
    }
}
